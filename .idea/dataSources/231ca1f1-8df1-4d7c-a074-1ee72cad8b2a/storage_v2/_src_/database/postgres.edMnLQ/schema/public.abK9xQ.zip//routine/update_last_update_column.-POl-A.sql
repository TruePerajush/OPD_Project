create function update_last_update_column() returns trigger
    language plpgsql
as
$$
begin
    new.last_update = now();
    return new;
end;
$$;

alter function update_last_update_column() owner to postgres;

grant execute on function update_last_update_column() to anon;

grant execute on function update_last_update_column() to authenticated;

grant execute on function update_last_update_column() to service_role;

